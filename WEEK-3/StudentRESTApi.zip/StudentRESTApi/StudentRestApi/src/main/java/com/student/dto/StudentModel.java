package com.student.dto;
import com.student.controller.StudentController;
import lombok.*;
import org.springframework.hateoas.RepresentationModel;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
@Getter
public class StudentModel extends RepresentationModel<StudentModel{
    private final StudentResponse student;
    public StudentModel(StudentResponse student) {
        this.student = student;

        add(linkTo(methodOn(StudentController.class)
                .getStudent(student.getId())).withSelfRel());

        add(linkTo(methodOn(StudentController.class)
                .getAllStudents(0,10, "firstName")).withRel("all-student"));

        add(linkTo(methodOn(StudentController.class)
                .getByCourse(student.getCourse())).withRel("same-course"));
    }
}
