package com.student.controller;

public class AuthController {
    private final AuthenticationManager authManager;
    private final UserDetailsService u
}
