package com.student.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.aspectj.bridge.IMessage;

@Entity
@Table(name  ="students")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "First name is Required")
    @Size(min = 2,max=50, message = "2-50")
    @Column(name = "first_name",nullable = false)
    private String firstName;

    @NotBlank(message = "Last name is required")
    @Column(name = "last_name", nullable = false)
    private String lastName;

    @Email(message = "must be valid")
    @NotBlank(message = "required")
    @Column(unique = true, nullable = false)
    private String email;

    @Min(value = 0)
    @Max(value = 100)
    private Integer age;

    @NotBlank
    private String course;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private Status status = Status.Active;
    public enum Status{Active,Inactive,Graduated}
}
