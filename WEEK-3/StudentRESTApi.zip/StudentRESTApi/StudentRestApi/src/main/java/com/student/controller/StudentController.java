package com.student.controller;

import com.student.dto.StudentModel;
import com.student.dto.StudentRequest;
import com.student.dto.StudentResponse;
import com.student.service.StudentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Positive;
import jakarta.websocket.server.PathParam;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/students")
@RequiredArgsConstructor
@Tag(name = "Students", description = "Student management")
public class StudentController {
    private final StudentService studentService;
    @GetMapping
    @Operation
    public ResponseEntity<Page<StudentResponse>> getAllStudents(
            @RequestParam(defaultValue = "0")         int page,
            @RequestParam(defaultValue = "10")        int size,
            @RequestParam(defaultValue = "firstName") String sortBy){
        return ResponseEntity.ok(studentService.getAllStudents(page, size, sortBy));
    }
    @GetMapping("/{id}")
    public ResponseEntity<StudentResponse> getStudent(@PathVariable Long id){
        return ResponseEntity.ok(studentService.getStudentById(id));
    }
    @GetMapping("/{id}/links")
    public ResponseEntity<StudentModel> getStudentWithLinks(@PathVariable Long id){
        StudentResponse response = studentService.getStudentById(id);
        return ResponseEntity.ok(new StudentModel(response));
    }
    @GetMapping("/course/{course}")
    public ResponseEntity<List<StudentResponse>> getByCourse(@PathVariable String course){
        return ResponseEntity.ok(studentService.getStudentByCourse(course));
    }
    @GetMapping ("/search")
    public ResponseEntity<List<StudentResponse>> search(@RequestParam String name){
        return ResponseEntity.ok(studentService.SearchByName(name));
    }
    @PostMapping
    public ResponseEntity<StudentResponse> createStudent(@Valid @RequestBody StudentRequest request){
        StudentResponse response = studentService.createStudent(request);

        HttpHeaders headers = new HttpHeaders();
        headers.add(" ",String.valueOf(response.getId()));

        return ResponseEntity.status(HttpStatus.CREATED).headers(headers).body(response);
    }
    @PutMapping("/id")
    public ResponseEntity<StudentResponse> updateStudent(@PathVariable Long id, @Valid @RequestBody StudentRequest request){
        return ResponseEntity.ok(studentService.updateStudent(id, request));
    }
    @PutMapping("/{id}/age")
    public ResponseEntity<StudentResponse> updateAge(@PathVariable Long id, @RequestParam @Positive Integer age){
        StudentResponse curr = studentService.getStudentById(id);
        StudentRequest patch = StudentRequest.builder()
                .firstName(curr.getFirstName())
                .lastName(curr.getLastName())
                .email(curr.getEmail())
                .age(age)
                .course(curr.getCourse())
                .build();
        return ResponseEntity.ok(studentService.updateStudent(id, patch));
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteStudent(@PathVariable Long id){
        studentService.deleteStudent(id);
        return ResponseEntity.noContent().build();
    }
}
