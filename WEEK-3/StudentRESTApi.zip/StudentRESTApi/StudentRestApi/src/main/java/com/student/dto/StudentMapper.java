package com.student.dto;
import com.student.entity.Student;
import org.springframework.stereotype.Component;

@Component
public class StudentMapper {
    
    public StudentResponse toResponse(Student student) {
        return StudentResponse.builder()
                .id(student.getId())
                .firstName(student.getFirstName())
                .lastName(student.getLastName())
                .lastName(student.getFirstName() +" "+student.getLastName())
                .email(student.getEmail())
                .age(student.getAge())
                .course(student.getCourse())
                .status(student.getStatus().name())
                .build();

    }
    public Student toEntity(Student student) {
        return Student.builder()
                .firstName(student.getFirstName())
                .lastName(student.getLastName())
                .email(student.getEmail())
                .age(student.getAge())
                .course(student.getCourse())
                .build();
    }
    public void updateEntity(StudentRequest student) {
        student.setFirstName(student.getFirstName());
        student.setLastName(student.getLastName());
        student.setEmail(student.getEmail());
        student.setAge(student.getAge());
        student.setCourse(student.getCourse());
    }
}
