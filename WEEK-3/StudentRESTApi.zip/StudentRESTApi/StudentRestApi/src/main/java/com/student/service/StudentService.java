package com.student.service;
import com.student.dto.*;
import com.student.entity.*;
import com.student.exception.StudentNotFoundException;
import com.student.repository.StudentRepository;
import lombok.*;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class StudentService {
    private final StudentRepository studentRepository;
    private final StudentMapper studentmapper;
    //CREATE
    public StudentResponse createStudent(StudentRequest student){
        if(StudentRepository.existsByEmail(student.getEmail())){
            throw new IllegalArgumentException("Email already exists");
        }
        Student saved = studentRepository.save(studentmapper.toEntity(student));
        return studentmapper.toResponse(saved);
    }
    //READ ALL - with pagination + sorting
    public Page<StudentResponse> getAllStudents(int page, int size, String sortBy){
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy).ascending());
        return studentRepository.findAll(pageable).map(studentmapper::toResponse);
    }
    //READ by ONE
    public StudentResponse getStudentById(Long id){
        Student student = studentRepository.findById(id).orElseThrow(() -> new StudentNotFoundException(id));
        return studentmapper.toResponse(student);
    }
    //READ by Course
    public List<StudentRepository> getStudentByCourse(String course){
        return StudentRepository.findByCourse(course).stream().map(studentmapper::toResponse).collect(Collectors.toList());
    }
    //READ by Name
    public List<StudentRepository> SearchByName(String name){
        return StudentRepository.findByFirstNameContainingIgnoreCase(name).stream().map(studentmapper::toResponse).collect(Collectors.toList());
    }
    //UPDATE
    public StudentResponse updateStudent(Long id, StudentRequest request){
        Student existing = studentRepository.findById(id).orElseThrow(()->new StudentNotFoundException(id));
        studentmapper.updateEntity(request, existing);
        return studentmapper.toResponse(studentRepository.save(existing));
    }
    //DELETE
    public void deleteStudent(Long id){
        if(!studentRepository.existsById(id)){
            throw new StudentNotFoundException(id);
        }
        studentRepository.deleteById(id);
    }
}