package com.student.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.Date;
import java.util.function.Function;
@Component
public class JwtUtil {
    @Value("${jwt.secret}")
    private String secret;
    @Value("${jwt.expiration}")
    private Long expiration;

    private Key key(){
        return Keys.hmacShaKeyFor(secret.getBytes());
    }

    public String generateToken(String username){
        return Jwts.builder()
                .setSubject(username)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + expiration))
                .signWith(key(), SignatureAlgorithm.HS256)
                .compact();
    }
    public String extractUsername(String token){
        return getClaim(token, Claims::getSubject);
    }
    public boolean isValid(String token, UserDetails user){
        return extractUsername(token).equals(user.getUsername()) && !isExpired(token);
    }
    public boolean isExpired(String token){
        return getClaim(token, Claims::getExpiration).before(new Date());
    }
    private <T> T getClaim(String token, Function<Claims, T> resolver){
        return resolver.apply(Jwts.parserBuilder().setSigningKey(key()).build().parseClaimsJws(token).getBody());
    }
}
