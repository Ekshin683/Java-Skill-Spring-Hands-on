package com.student.config;
public class SwaggerConfig {
}
